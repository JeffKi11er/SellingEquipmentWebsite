package com.example.tntn.fragment;

import com.example.tntn.R;

public class SavedFragment extends BaseFragment {
    @Override
    protected int getLayoutRes() {
        return R.layout.activity_fragment_saved;
    }

    @Override
    public String getTitle() {
        return "Saved";
    }
}
