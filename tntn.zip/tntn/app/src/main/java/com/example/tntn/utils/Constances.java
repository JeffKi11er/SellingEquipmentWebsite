package com.example.tntn.utils;

public interface Constances {
    String ITEM = "item";
    String TITLE = "title";
    String DESC = "description";
    String LINK = "link";
    String PUB_DATE = "pubDate";
    String IMAGE = "image";
}
