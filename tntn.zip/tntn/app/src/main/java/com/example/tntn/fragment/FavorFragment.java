package com.example.tntn.fragment;

import com.example.tntn.R;

public class FavorFragment extends BaseFragment {
    @Override
    protected int getLayoutRes() {
        return R.layout.activity_fragment_favor;
    }

    @Override
    public String getTitle() {
        return "Favorite";
    }
}
