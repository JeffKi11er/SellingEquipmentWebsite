package com.t3h.myprojectnoteupdate;

public interface AppConstants {
    String INTENT_TITLE = "intent_title";
    String INTENT_DESCRIPT = "intent_description";
    String INTENT_TIME = "intent_time";
    String INTENT_DATE = "intent_date";
    String INTENT_TASK = "intent_task";
    String INTENT_DELETE = "intent_delete";

    int ACTIVITY_REQUEST_CODE = 200;
}
