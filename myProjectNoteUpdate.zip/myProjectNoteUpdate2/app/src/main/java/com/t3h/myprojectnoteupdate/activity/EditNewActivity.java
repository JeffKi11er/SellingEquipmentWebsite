package com.t3h.myprojectnoteupdate.activity;

import android.support.v7.app.ActionBar;

import com.t3h.myprojectnoteupdate.R;
import com.t3h.myprojectnoteupdate.databinding.NewsEventsLayoutBinding;

public class EditNewActivity extends BaseActivity<NewsEventsLayoutBinding> {
    @Override
    protected void initAct() {
        ActionBar actionBar3 = getSupportActionBar();
        actionBar3.setTitle("New Note");///co thay doi khi click vao item
        actionBar3.setDisplayHomeAsUpEnabled(true);
    }

    @Override
    protected int getLayoutId() {
        return R.layout.news_events_layout;
    }
}
