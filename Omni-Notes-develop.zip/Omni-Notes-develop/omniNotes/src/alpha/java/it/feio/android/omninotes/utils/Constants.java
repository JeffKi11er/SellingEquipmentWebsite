package it.feio.android.omninotes.utils;


public interface Constants extends ConstantsBase {

	String TAG = "Omni Notes Alpha";
	String EXTERNAL_STORAGE_FOLDER = "Omni Notes Alpha";
	String PACKAGE = "it.feio.android.omninotes.alpha";
	String PREFS_NAME = PACKAGE + "_preferences";

}
