package com.t3h.myprojectnoteupdate.item;

public class ItemFlickr {
    private int thumb;

    public ItemFlickr(int thumb) {
        this.thumb = thumb;
    }

    public int getThumb() {
        return thumb;
    }

    public void setThumb(int thumb) {
        this.thumb = thumb;
    }
}
