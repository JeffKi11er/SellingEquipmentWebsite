package com.phongbm.musicplayer.view;

public interface MP3PlayViewListener {
    void next();
    void prev();
    void play();
    void repeat();
    void shuffle();
}
