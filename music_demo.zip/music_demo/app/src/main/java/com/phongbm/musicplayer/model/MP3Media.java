package com.phongbm.musicplayer.model;

public abstract class MP3Media {
}
